﻿using System;
using Xamarin.Forms;

namespace DemoApp1
{
    public partial class MainPage : ContentPage
    {
        string Hola = "";
        public MainPage()
        {
            InitializeComponent();        
        }

        public void Estado2()
        {
            if (int.Parse(LblPresion.Text) <= 109)
            {
                if (int.Parse(LblFrecuencia.Text) <= 69)
                {
                    LblPresionArterial.Text = "La presión arterial es baja.";
                }
                else
                {
                    LblPresionArterial.Text = "¡Enhorabuena! Su Presión Arterial está dentro de los rangos normales.";
                    Hola = LblPresionArterial.Text;
                }
            }
            else if (true)
            {
                LblPresionArterial.Text = "¡Enhorabuena! Su Presión Arterial está dentro de los rangos normales.";
                Hola = LblPresionArterial.Text;
            }
        }

        public void EstadoArterial()
        {
            if (int.Parse(LblPresion.Text) <= 120)
            {
                if (int.Parse(LblFrecuencia.Text) <= 80)
                {
                    Estado2();
                }
                else
                {
                    LblPresionArterial.Text = "Hipertensión Leve.";
                }
            }
            else
            {
                LblPresionArterial.Text = "Hipertensión leve.";
            }
        }

        public void Diabetes()
        {
            if (int.Parse(LblGlucosa.Text) >= 7)
            {
                if (int.Parse(LblColesterol.Text) >= 200)
                {
                    Diabetes1();
                }
                else
                {
                    LblTipoDiabetes.Text = "No diabetico";
                }
            }
            else
            {
                LblTipoDiabetes.Text = "No diabetico";
            }
        }

        public void Diabetes1()
        {
            if (int.Parse(LblGlucosa.Text) <= 7)
            {
                if (int.Parse(LblColesterol.Text) <= 200)
                {
                    LblTipoDiabetes.Text = "No diabetico";
                }
                else
                {
                    LblTipoDiabetes.Text = "Diabetes tipo 1";
                }
            }
            else
            {
                LblTipoDiabetes.Text = "Diabetes tipo 1";
            }
        }

        private void BtnCalcular_Clicked(object sender, EventArgs e)
        {
            EstadoArterial();
        }

        private void LblPresion_Completed(object sender, EventArgs e)
        {
            BarPro.ProgressTo(.25, 250, Easing.Linear);
            LblBarProgress.Text = "25%";
        }

        private void LblFrecuencia_Completed(object sender, EventArgs e)
        {
            BarPro.ProgressTo(.50, 250, Easing.Linear);
            LblBarProgress.Text = "50%";
        }

        private void LblGlucosa_Completed(object sender, EventArgs e)
        {
            BarPro.ProgressTo(.75, 250, Easing.Linear);
            LblBarProgress.Text = "75%";
        }

        private void LblColesterol_Completed(object sender, EventArgs e)
        {
            BarPro.ProgressTo(1, 250, Easing.Linear);
            LblBarProgress.Text = "100%";
        }

        public void LimpiarCampos()
        {

            BarPro.ProgressTo(0, 250, Easing.Linear);
            LblBarProgress.Text = "0%";
            LblColesterol.Text = "";
            LblFrecuencia.Text = "";
            LblGlucosa.Text = "";
            LblPresion.Text = "";
            LblNombre.Text = "";
            LblPresionArterial.Text = "Presion arterial ";
            LblTipoDiabetes.Text = "Diabetes tipo: ";
        }

        #region Sin uso
        private void LblColesterol_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void LblPresion_TextChanged(object sender, TextChangedEventArgs e)
        {
            BarPro.ProgressTo(.25, 250, Easing.Linear);
            LblBarProgress.Text = "25%";
        }
        private void LblGlucosa_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void LblFrecuencia_TextChanged(object sender, TextChangedEventArgs e)
        {
            string Nombre = LblNombre.Text.ToString();
            string cadena = $"Bienvenido {Nombre}. Llene sus datos";
            LblPrincipal.Text = cadena;
        }
        #endregion

        private void BtnReiniciarApp_Clicked(object sender, EventArgs e)
        {
            LimpiarCampos();
        }
    }
}
